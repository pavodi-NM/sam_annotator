from setuptools import setup, find_packages

setup(
    packages=find_packages(exclude=['test*', 'documentation', 'examples']),
)