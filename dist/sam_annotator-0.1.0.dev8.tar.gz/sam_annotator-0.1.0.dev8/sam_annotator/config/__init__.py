"""
Configuration utilities for SAM Annotator
""" 