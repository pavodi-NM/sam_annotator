"""
SAM Annotator - A tool for image annotation using Segment Anything Model (SAM)
"""

# from .core.annotator import SamAnnotator
# from .core.predictor import Predictor
# from .core.validation import ValidationManager
# from .data.dataset_manager import DatasetManager

__version__ = '0.1.0.dev19'