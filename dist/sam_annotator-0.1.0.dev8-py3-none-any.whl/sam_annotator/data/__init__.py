"""
Data handling components for SAM Annotator
""" 